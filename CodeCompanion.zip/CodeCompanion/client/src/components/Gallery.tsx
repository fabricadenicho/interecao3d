import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "./ui/card";

interface VisualizationCard {
  id: string;
  title: string;
  description: string;
  image: string;
  route: string;
  tags: string[];
  difficulty: "Beginner" | "Intermediate" | "Advanced";
}

const visualizations: VisualizationCard[] = [
  {
    id: "neural-network",
    title: "Playground de Rede Neural",
    description: "Crie e manipule arquiteturas de redes neurais em um ambiente 3D interativo. Observe a propagação de sinais e simule processos de treinamento.",
    image: "https://placehold.co/600x400/111119/4f46e5?text=Rede+Neural",
    route: "/neural-network",
    tags: ["IA", "Machine Learning", "Interativo"],
    difficulty: "Intermediate"
  },
  {
    id: "atomic-simulator",
    title: "Simulador de Estrutura Atômica",
    description: "Explore a estrutura atômica com núcleo realista e mecânica orbital dos elétrons. Visualize prótons, nêutrons e camadas eletrônicas.",
    image: "https://placehold.co/600x400/111119/00BFFF?text=Atomo",
    route: "/atomic-simulator",
    tags: ["Física", "Química", "3D"],
    difficulty: "Beginner"
  },
  {
    id: "dna-helix",
    title: "Dupla Hélice de DNA",
    description: "Modelo 3D interativo da estrutura do DNA mostrando pares de bases, espinha dorsal açúcar-fosfato e ligações moleculares.",
    image: "https://placehold.co/600x400/111119/22c55e?text=DNA",
    route: "/dna-helix",
    tags: ["Biologia", "Genética", "Molecular"],
    difficulty: "Intermediate"
  },
  {
    id: "solar-system",
    title: "Explorador do Sistema Solar",
    description: "Navegue pelo nosso sistema solar com órbitas planetárias precisas, tamanhos e recursos de exploração interativa.",
    image: "https://placehold.co/600x400/111119/f59e0b?text=Sistema+Solar",
    route: "/solar-system",
    tags: ["Astronomia", "Física", "Espaço"],
    difficulty: "Beginner"
  },
  {
    id: "particle-field",
    title: "Campo de Partículas Quânticas",
    description: "Visualize conceitos de mecânica quântica com campos de partículas interativos, funções de onda e distribuições de probabilidade.",
    image: "https://placehold.co/600x400/111119/8b5cf6?text=Quantico",
    route: "/particle-field",
    tags: ["Física Quântica", "Avançado", "Simulação"],
    difficulty: "Advanced"
  },
  {
    id: "math-surface",
    title: "Superfície Matemática 3D",
    description: "Explore funções matemáticas em três dimensões incluindo função sinc, ondas bidimensionais e ondulações com controles interativos.",
    image: "https://placehold.co/600x400/111119/ff6b6b?text=Matematica",
    route: "/math-surface",
    tags: ["Matemática", "Funções", "Ondas"],
    difficulty: "Intermediate"
  }
];

export default function Gallery() {
  const navigate = useNavigate();

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner": return "bg-green-500/20 text-green-400 border-green-500/50";
      case "Intermediate": return "bg-yellow-500/20 text-yellow-400 border-yellow-500/50";
      case "Advanced": return "bg-red-500/20 text-red-400 border-red-500/50";
      default: return "bg-gray-500/20 text-gray-400 border-gray-500/50";
    }
  };

  const getDifficultyText = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner": return "Iniciante";
      case "Intermediate": return "Intermediário";
      case "Advanced": return "Avançado";
      default: return difficulty;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#111119] via-[#1a1a2e] to-[#16213e]">
      {/* Hero Section */}
      <div className="container mx-auto px-4 py-16">
        <header className="text-center mb-16">
          <h1 className="text-6xl md:text-8xl font-black mb-6 bg-gradient-to-r from-[#a7a2f5] via-white to-[#a7a2f5] bg-clip-text text-transparent">
            Galeria Interativa
          </h1>
          <p className="text-xl md:text-2xl text-gray-400 max-w-4xl mx-auto leading-relaxed">
            Explore as fronteiras da ciência através de visualizações 3D imersivas. De redes neurais à mecânica quântica, 
            descubra os blocos fundamentais do nosso universo de formas nunca antes possíveis.
          </p>
        </header>

        {/* Visualizations Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {visualizations.map((viz) => (
            <Card
              key={viz.id}
              className="group bg-black/40 border-white/10 hover:border-[#4f46e5]/50 transition-all duration-500 hover:transform hover:-translate-y-2 hover:shadow-2xl hover:shadow-[#4f46e5]/20 cursor-pointer backdrop-blur-sm"
              onClick={() => navigate(viz.route)}
            >
              <div className="relative overflow-hidden rounded-t-lg">
                <img 
                  src={viz.image} 
                  alt={viz.title}
                  className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <div className={`absolute top-4 right-4 px-3 py-1 rounded-full text-xs font-medium border ${getDifficultyColor(viz.difficulty)}`}>
                  {getDifficultyText(viz.difficulty)}
                </div>
              </div>
              
              <CardContent className="p-6">
                <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-[#a7a2f5] transition-colors">
                  {viz.title}
                </h3>
                <p className="text-gray-400 mb-4 leading-relaxed">
                  {viz.description}
                </p>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {viz.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-3 py-1 text-xs font-medium bg-[#4f46e5]/20 text-[#a7a2f5] rounded-full border border-[#4f46e5]/30"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                <button className="w-full bg-gradient-to-r from-[#4f46e5] to-[#818cf8] hover:from-[#6366f1] hover:to-[#a78bfa] text-white font-bold py-3 px-6 rounded-lg transition-all duration-300 hover:shadow-lg hover:shadow-[#4f46e5]/30 group-hover:transform group-hover:scale-105">
                  Explorar Visualização
                </button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Footer */}
        <footer className="text-center mt-20 text-gray-500">
          <p className="text-lg">
            Construído com Three.js • WebGL • Tecnologias Web Modernas
          </p>
          <p className="mt-2">
            Experimente o futuro da educação interativa
          </p>
        </footer>
      </div>
    </div>
  );
}
