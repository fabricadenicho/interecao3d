import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { DragControls } from "three/examples/jsm/controls/DragControls.js";
import { EffectComposer } from "three/examples/jsm/postprocessing/EffectComposer.js";
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/examples/jsm/postprocessing/UnrealBloomPass.js";

interface NetworkLayer {
  neurons: THREE.Mesh[];
  position: THREE.Vector3;
  neuronCount: number;
}

export default function NeuralNetworkPlayground() {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const composerRef = useRef<EffectComposer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const dragControlsRef = useRef<DragControls | null>(null);
  const animationIdRef = useRef<number>(0);
  
  const [networkStructure, setNetworkStructure] = useState([4, 6, 6, 3]);
  const [isTraining, setIsTraining] = useState(false);
  const [bloomEnabled, setBloomEnabled] = useState(true);
  const [selectedLayer, setSelectedLayer] = useState(-1);
  
  const layersRef = useRef<NetworkLayer[]>([]);
  const connectionsRef = useRef<THREE.Line[]>([]);
  const draggableObjectsRef = useRef<THREE.Mesh[]>([]);
  
  const navigate = useNavigate();

  useEffect(() => {
    if (!containerRef.current) return;

    // Initialize Three.js scene
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x111119, 0.05);
    sceneRef.current = scene;

    // Camera setup
    const camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    camera.position.set(0, 5, 20);
    cameraRef.current = camera;

    // Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.toneMapping = THREE.ReinhardToneMapping;
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.2);
    scene.add(ambientLight);
    
    const pointLight = new THREE.PointLight(0x818cf8, 1.5, 100);
    pointLight.position.set(0, 0, 10);
    scene.add(pointLight);

    // Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.minDistance = 5;
    controls.maxDistance = 100;
    controlsRef.current = controls;

    // Post-processing
    const renderScene = new RenderPass(scene, camera);
    const bloomPass = new UnrealBloomPass(
      new THREE.Vector2(window.innerWidth, window.innerHeight),
      1.0,
      0.1,
      0.1
    );
    
    const composer = new EffectComposer(renderer);
    composer.addPass(renderScene);
    composer.addPass(bloomPass);
    composerRef.current = composer;

    // Build initial network
    buildNetwork();

    // Animation loop
    const animate = () => {
      animationIdRef.current = requestAnimationFrame(animate);
      
      if (controlsRef.current) {
        controlsRef.current.update();
      }
      
      // Update training animation
      if (isTraining) {
        updateTrainingAnimation();
      }
      
      if (composerRef.current && bloomEnabled) {
        composerRef.current.render();
      } else if (rendererRef.current) {
        rendererRef.current.render(scene, camera);
      }
    };
    animate();

    // Handle window resize
    const handleResize = () => {
      if (cameraRef.current && rendererRef.current) {
        cameraRef.current.aspect = window.innerWidth / window.innerHeight;
        cameraRef.current.updateProjectionMatrix();
        rendererRef.current.setSize(window.innerWidth, window.innerHeight);
        
        if (composerRef.current) {
          composerRef.current.setSize(window.innerWidth, window.innerHeight);
        }
      }
    };
    
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      
      if (animationIdRef.current) {
        cancelAnimationFrame(animationIdRef.current);
      }
      
      if (containerRef.current && rendererRef.current) {
        containerRef.current.removeChild(rendererRef.current.domElement);
      }
      
      // Cleanup Three.js objects
      if (sceneRef.current) {
        sceneRef.current.clear();
      }
      if (rendererRef.current) {
        rendererRef.current.dispose();
      }
    };
  }, []);

  const buildNetwork = () => {
    if (!sceneRef.current) return;

    // Clear existing network
    layersRef.current.forEach(layer => {
      layer.neurons.forEach(neuron => {
        sceneRef.current?.remove(neuron);
      });
    });
    
    connectionsRef.current.forEach(connection => {
      sceneRef.current?.remove(connection);
    });
    
    layersRef.current = [];
    connectionsRef.current = [];
    draggableObjectsRef.current = [];

    const layerSpacing = 6;
    const totalWidth = (networkStructure.length - 1) * layerSpacing;

    // Create layers
    networkStructure.forEach((neuronCount, layerIndex) => {
      const layer: NetworkLayer = {
        neurons: [],
        position: new THREE.Vector3(
          layerIndex * layerSpacing - totalWidth / 2,
          0,
          0
        ),
        neuronCount
      };

      const neuronSpacing = Math.min(3, 10 / neuronCount);
      const layerHeight = (neuronCount - 1) * neuronSpacing;

      for (let neuronIndex = 0; neuronIndex < neuronCount; neuronIndex++) {
        const geometry = new THREE.SphereGeometry(0.3, 16, 16);
        const material = new THREE.MeshStandardMaterial({
          color: layerIndex === 0 ? 0x4ade80 : layerIndex === networkStructure.length - 1 ? 0xf87171 : 0x60a5fa,
          emissive: 0x333333,
          roughness: 0.5,
          metalness: 0.3
        });

        const neuron = new THREE.Mesh(geometry, material);
        neuron.position.set(
          layer.position.x,
          neuronIndex * neuronSpacing - layerHeight / 2,
          layer.position.z
        );

        neuron.userData = { layer: layerIndex, neuron: neuronIndex };
        
        layer.neurons.push(neuron);
        draggableObjectsRef.current.push(neuron);
        sceneRef.current?.add(neuron);
      }

      layersRef.current.push(layer);
    });

    // Create connections
    for (let layerIndex = 0; layerIndex < layersRef.current.length - 1; layerIndex++) {
      const currentLayer = layersRef.current[layerIndex];
      const nextLayer = layersRef.current[layerIndex + 1];

      currentLayer.neurons.forEach(neuron1 => {
        nextLayer.neurons.forEach(neuron2 => {
          const points = [neuron1.position, neuron2.position];
          const geometry = new THREE.BufferGeometry().setFromPoints(points);
          const material = new THREE.LineBasicMaterial({
            color: 0x6366f1,
            transparent: true,
            opacity: 0.6
          });

          const connection = new THREE.Line(geometry, material);
          connectionsRef.current.push(connection);
          sceneRef.current?.add(connection);
        });
      });
    }

    // Setup drag controls
    if (dragControlsRef.current) {
      dragControlsRef.current.dispose();
    }
    
    if (cameraRef.current && rendererRef.current) {
      const dragControls = new DragControls(
        draggableObjectsRef.current,
        cameraRef.current,
        rendererRef.current.domElement
      );
      
      dragControls.addEventListener('dragstart', (event) => {
        if (controlsRef.current) {
          controlsRef.current.enabled = false;
        }
        event.object.material.emissive.set(0xffa500);
      });
      
      dragControls.addEventListener('dragend', (event) => {
        if (controlsRef.current) {
          controlsRef.current.enabled = true;
        }
        event.object.material.emissive.set(0x333333);
      });
      
      dragControlsRef.current = dragControls;
    }
  };

  const updateTrainingAnimation = () => {
    const time = Date.now() * 0.001;
    
    layersRef.current.forEach((layer, layerIndex) => {
      layer.neurons.forEach((neuron, neuronIndex) => {
        const intensity = Math.sin(time * 2 + layerIndex * 0.5 + neuronIndex * 0.2) * 0.5 + 0.5;
        neuron.material.emissive.setScalar(intensity * 0.3);
      });
    });
  };

  const propagateSignal = () => {
    let delay = 0;
    const signalDuration = 300;

    layersRef.current.forEach((layer, layerIndex) => {
      setTimeout(() => {
        layer.neurons.forEach(neuron => {
          neuron.material.emissive.setHex(0xffffff);
          
          setTimeout(() => {
            neuron.material.emissive.setHex(0x333333);
          }, signalDuration);
        });
      }, delay);
      
      delay += signalDuration + 100;
    });
  };

  const simulateTraining = () => {
    setIsTraining(true);
    setTimeout(() => {
      setIsTraining(false);
    }, 5000);
  };

  const addHiddenLayer = () => {
    const newStructure = [...networkStructure];
    newStructure.splice(-1, 0, 6); // Add layer before output
    setNetworkStructure(newStructure);
    buildNetwork();
  };

  const removeLayer = (layerIndex: number) => {
    if (networkStructure.length <= 3 || layerIndex === 0 || layerIndex === networkStructure.length - 1) return;
    
    const newStructure = networkStructure.filter((_, index) => index !== layerIndex);
    setNetworkStructure(newStructure);
    buildNetwork();
  };

  const adjustNeurons = (layerIndex: number, change: number) => {
    const newStructure = [...networkStructure];
    const newCount = Math.max(1, Math.min(12, newStructure[layerIndex] + change));
    newStructure[layerIndex] = newCount;
    setNetworkStructure(newStructure);
    buildNetwork();
  };

  useEffect(() => {
    buildNetwork();
  }, [networkStructure]);

  useEffect(() => {
    if (composerRef.current) {
      const bloomPass = composerRef.current.passes.find(pass => pass instanceof UnrealBloomPass) as UnrealBloomPass;
      if (bloomPass) {
        bloomPass.enabled = bloomEnabled;
      }
    }
  }, [bloomEnabled]);

  return (
    <div className="w-full h-screen relative overflow-hidden">
      <div ref={containerRef} className="w-full h-full" />
      
      {/* Control Panel */}
      <div className="absolute top-5 left-5 bg-black/80 backdrop-blur-md rounded-xl p-4 border border-white/20 max-w-xs">
        <button
          onClick={() => navigate("/")}
          className="mb-4 w-full bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-500 hover:to-gray-600 text-white font-bold py-2 px-4 rounded-lg transition-all duration-300"
        >
          ← Voltar à Galeria
        </button>
        
        <button
          onClick={propagateSignal}
          className="mb-3 w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-400 hover:to-purple-500 text-white font-bold py-2 px-4 rounded-lg transition-all duration-300"
        >
          Propagar Sinal
        </button>
        
        <button
          onClick={simulateTraining}
          disabled={isTraining}
          className="mb-3 w-full bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-400 hover:to-teal-500 disabled:from-gray-500 disabled:to-gray-600 text-white font-bold py-2 px-4 rounded-lg transition-all duration-300 disabled:cursor-not-allowed"
        >
          {isTraining ? "Treinando..." : "🧠 Simular Treino"}
        </button>
        
        <button
          onClick={addHiddenLayer}
          className="mb-3 w-full bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500 text-white font-bold py-2 px-4 rounded-lg transition-all duration-300"
        >
          Adicionar Camada Oculta
        </button>
        
        <div className="flex items-center justify-between text-white text-sm py-2 border-t border-white/20 mt-3">
          <label htmlFor="bloom-toggle">✨ Efeito Bloom</label>
          <input
            id="bloom-toggle"
            type="checkbox"
            checked={bloomEnabled}
            onChange={(e) => setBloomEnabled(e.target.checked)}
            className="w-8 h-4 bg-gray-600 rounded-full relative cursor-pointer appearance-none checked:bg-blue-500 transition-colors"
          />
        </div>
      </div>

      {/* Layer Controls */}
      <div className="absolute bottom-5 left-1/2 transform -translate-x-1/2 flex gap-4 flex-wrap justify-center max-w-4xl">
        {networkStructure.map((neuronCount, layerIndex) => (
          <div
            key={layerIndex}
            className="bg-black/80 backdrop-blur-md rounded-lg p-3 border border-white/20 text-white text-center min-w-[120px]"
          >
            <div className="text-xs font-semibold mb-2">
              {layerIndex === 0 ? "Entrada" : layerIndex === networkStructure.length - 1 ? "Saída" : `Oculta ${layerIndex}`}
            </div>
            <div className="text-lg font-bold mb-2">{neuronCount} neurônios</div>
            <div className="flex gap-1 justify-center">
              <button
                onClick={() => adjustNeurons(layerIndex, -1)}
                className="w-8 h-8 bg-red-500/70 hover:bg-red-500 rounded-full text-white font-bold transition-colors"
                disabled={neuronCount <= 1}
              >
                -
              </button>
              <button
                onClick={() => adjustNeurons(layerIndex, 1)}
                className="w-8 h-8 bg-green-500/70 hover:bg-green-500 rounded-full text-white font-bold transition-colors"
                disabled={neuronCount >= 12}
              >
                +
              </button>
              {layerIndex > 0 && layerIndex < networkStructure.length - 1 && (
                <button
                  onClick={() => removeLayer(layerIndex)}
                  className="w-8 h-8 bg-gray-500/70 hover:bg-gray-500 rounded-full text-white font-bold transition-colors"
                >
                  ×
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Instructions */}
      <div className="absolute top-5 right-5 bg-black/80 backdrop-blur-md rounded-xl p-4 border border-white/20 max-w-sm">
        <h3 className="text-white font-bold mb-2">Instruções</h3>
        <ul className="text-gray-300 text-sm space-y-1">
          <li>• Arraste neurônios para mover camadas</li>
          <li>• Use controles para ajustar estrutura da rede</li>
          <li>• Observe propagação de sinais em tempo real</li>
          <li>• Simule treinamento para ver efeitos de aprendizado</li>
          <li>• Alterne bloom para melhoria visual</li>
        </ul>
      </div>
    </div>
  );
}
