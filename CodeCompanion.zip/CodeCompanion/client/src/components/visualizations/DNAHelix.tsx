import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";

interface BasePair {
  base1: THREE.Mesh;
  base2: THREE.Mesh;
  bond: THREE.Line;
  position: number;
  type: "AT" | "GC";
}

export default function DNAHelix() {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const animationIdRef = useRef<number>(0);
  const clockRef = useRef<THREE.Clock>(new THREE.Clock());
  
  const [rotationSpeed, setRotationSpeed] = useState(0.5);
  const [showLabels, setShowLabels] = useState(true);
  const [highlightPairs, setHighlightPairs] = useState(false);
  
  const dnaGroupRef = useRef<THREE.Group | null>(null);
  const basePairsRef = useRef<BasePair[]>([]);
  
  const navigate = useNavigate();

  const baseColors = {
    A: 0xff6b6b, // Adenine - Red
    T: 0x4ecdc4, // Thymine - Teal
    G: 0x45b7d1, // Guanine - Blue
    C: 0xf9ca24, // Cytosine - Yellow
  };

  const dnaSequence = "ATCGATCGATCGATCGATCGATCGATCGATCG";

  useEffect(() => {
    if (!containerRef.current) return;

    // Initialize Three.js scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0a0f);
    sceneRef.current = scene;

    // Camera setup
    const camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    camera.position.set(10, 5, 10);
    cameraRef.current = camera;

    // Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
    scene.add(ambientLight);
    
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(10, 10, 5);
    scene.add(directionalLight);

    // Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.minDistance = 5;
    controls.maxDistance = 50;
    controlsRef.current = controls;

    // Build DNA helix
    buildDNAHelix();

    // Animation loop
    const animate = () => {
      animationIdRef.current = requestAnimationFrame(animate);
      
      // Rotate DNA helix
      if (dnaGroupRef.current) {
        dnaGroupRef.current.rotation.y += rotationSpeed * 0.01;
      }
      
      // Highlight base pairs effect
      if (highlightPairs) {
        const time = clockRef.current.getElapsedTime();
        basePairsRef.current.forEach((pair, index) => {
          const highlight = Math.sin(time * 2 + index * 0.3) * 0.5 + 0.5;
          pair.base1.material.emissive.setScalar(highlight * 0.3);
          pair.base2.material.emissive.setScalar(highlight * 0.3);
        });
      } else {
        basePairsRef.current.forEach(pair => {
          pair.base1.material.emissive.setScalar(0);
          pair.base2.material.emissive.setScalar(0);
        });
      }
      
      if (controlsRef.current) {
        controlsRef.current.update();
      }
      
      if (rendererRef.current && sceneRef.current) {
        rendererRef.current.render(sceneRef.current, camera);
      }
    };
    animate();

    // Handle window resize
    const handleResize = () => {
      if (cameraRef.current && rendererRef.current) {
        cameraRef.current.aspect = window.innerWidth / window.innerHeight;
        cameraRef.current.updateProjectionMatrix();
        rendererRef.current.setSize(window.innerWidth, window.innerHeight);
      }
    };
    
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      
      if (animationIdRef.current) {
        cancelAnimationFrame(animationIdRef.current);
      }
      
      if (containerRef.current && rendererRef.current) {
        containerRef.current.removeChild(rendererRef.current.domElement);
      }
      
      if (sceneRef.current) {
        sceneRef.current.clear();
      }
      if (rendererRef.current) {
        rendererRef.current.dispose();
      }
    };
  }, []);

  const buildDNAHelix = () => {
    if (!sceneRef.current) return;

    // Clear existing DNA
    if (dnaGroupRef.current) {
      sceneRef.current.remove(dnaGroupRef.current);
    }
    basePairsRef.current = [];

    const dnaGroup = new THREE.Group();
    
    const helixRadius = 2;
    const helixHeight = 20;
    const basePairSpacing = 0.6;
    const totalPairs = Math.floor(helixHeight / basePairSpacing);

    // Create sugar-phosphate backbone
    const backboneGeometry = new THREE.CylinderGeometry(0.05, 0.05, helixHeight, 8);
    const backboneMaterial = new THREE.MeshStandardMaterial({ color: 0x666666 });
    
    // Left backbone
    const leftBackbone = new THREE.Mesh(backboneGeometry, backboneMaterial);
    leftBackbone.position.set(-helixRadius, 0, 0);
    dnaGroup.add(leftBackbone);
    
    // Right backbone
    const rightBackbone = new THREE.Mesh(backboneGeometry, backboneMaterial);
    rightBackbone.position.set(helixRadius, 0, 0);
    dnaGroup.add(rightBackbone);

    // Create base pairs
    for (let i = 0; i < totalPairs; i++) {
      const y = (i - totalPairs / 2) * basePairSpacing;
      const angle = (i / totalPairs) * Math.PI * 4; // Two full turns
      
      // Get base from sequence (repeat if necessary)
      const base1Type = dnaSequence[i % dnaSequence.length];
      const base2Type = getComplementaryBase(base1Type);
      
      // Create base geometries
      const baseGeometry = new THREE.BoxGeometry(0.3, 0.1, 0.3);
      
      // Base 1
      const base1Material = new THREE.MeshStandardMaterial({ 
        color: baseColors[base1Type as keyof typeof baseColors] 
      });
      const base1 = new THREE.Mesh(baseGeometry, base1Material);
      
      // Base 2
      const base2Material = new THREE.MeshStandardMaterial({ 
        color: baseColors[base2Type as keyof typeof baseColors] 
      });
      const base2 = new THREE.Mesh(baseGeometry, base2Material);
      
      // Position bases along helix
      const x1 = Math.cos(angle) * (helixRadius - 0.5);
      const z1 = Math.sin(angle) * (helixRadius - 0.5);
      const x2 = Math.cos(angle + Math.PI) * (helixRadius - 0.5);
      const z2 = Math.sin(angle + Math.PI) * (helixRadius - 0.5);
      
      base1.position.set(x1, y, z1);
      base2.position.set(x2, y, z2);
      
      // Create hydrogen bond between bases
      const bondPoints = [
        new THREE.Vector3(x1, y, z1),
        new THREE.Vector3(x2, y, z2)
      ];
      const bondGeometry = new THREE.BufferGeometry().setFromPoints(bondPoints);
      const bondMaterial = new THREE.LineBasicMaterial({ 
        color: 0xffffff, 
        transparent: true, 
        opacity: 0.5 
      });
      const bond = new THREE.Line(bondGeometry, bondMaterial);
      
      dnaGroup.add(base1);
      dnaGroup.add(base2);
      dnaGroup.add(bond);
      
      basePairsRef.current.push({
        base1,
        base2,
        bond,
        position: i,
        type: (base1Type === 'A' || base1Type === 'T') ? 'AT' : 'GC'
      });
    }
    
    dnaGroup.position.y = 0;
    sceneRef.current.add(dnaGroup);
    dnaGroupRef.current = dnaGroup;
  };

  const getComplementaryBase = (base: string): string => {
    switch (base) {
      case 'A': return 'T';
      case 'T': return 'A';
      case 'G': return 'C';
      case 'C': return 'G';
      default: return 'A';
    }
  };

  const randomizeSequence = () => {
    const bases = ['A', 'T', 'G', 'C'];
    let newSequence = '';
    for (let i = 0; i < 32; i++) {
      newSequence += bases[Math.floor(Math.random() * bases.length)];
    }
    // Update the sequence and rebuild
    buildDNAHelix();
  };

  useEffect(() => {
    buildDNAHelix();
  }, []);

  return (
    <div className="w-full h-screen relative overflow-hidden">
      <div ref={containerRef} className="w-full h-full" />
      
      {/* Control Panel */}
      <div className="absolute top-5 left-5 bg-black/80 backdrop-blur-md rounded-xl p-4 border border-white/20 max-w-xs">
        <button
          onClick={() => navigate("/")}
          className="mb-4 w-full bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-500 hover:to-gray-600 text-white font-bold py-2 px-4 rounded-lg transition-all duration-300"
        >
          ← Back to Gallery
        </button>
        
        <div className="mb-4">
          <label className="block text-white text-sm font-medium mb-2">
            Rotation Speed: {rotationSpeed.toFixed(1)}x
          </label>
          <input
            type="range"
            min="0"
            max="2"
            step="0.1"
            value={rotationSpeed}
            onChange={(e) => setRotationSpeed(Number(e.target.value))}
            className="w-full"
          />
        </div>
        
        <button
          onClick={randomizeSequence}
          className="mb-3 w-full bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-400 hover:to-teal-500 text-white font-bold py-2 px-4 rounded-lg transition-all duration-300"
        >
          🧬 Randomize Sequence
        </button>
        
        <div className="flex items-center justify-between text-white text-sm py-2 border-t border-white/20 mb-2">
          <label htmlFor="highlight-toggle">Highlight Pairs</label>
          <input
            id="highlight-toggle"
            type="checkbox"
            checked={highlightPairs}
            onChange={(e) => setHighlightPairs(e.target.checked)}
            className="w-8 h-4 bg-gray-600 rounded-full relative cursor-pointer appearance-none checked:bg-blue-500 transition-colors"
          />
        </div>
        
        <div className="flex items-center justify-between text-white text-sm py-2 border-t border-white/20">
          <label htmlFor="labels-toggle">Show Labels</label>
          <input
            id="labels-toggle"
            type="checkbox"
            checked={showLabels}
            onChange={(e) => setShowLabels(e.target.checked)}
            className="w-8 h-4 bg-gray-600 rounded-full relative cursor-pointer appearance-none checked:bg-blue-500 transition-colors"
          />
        </div>
      </div>

      {/* Base Pair Legend */}
      <div className="absolute top-5 right-5 bg-black/80 backdrop-blur-md rounded-xl p-4 border border-white/20">
        <h3 className="text-white font-bold mb-3">DNA Bases</h3>
        <div className="space-y-2 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-red-500 rounded"></div>
            <span className="text-gray-300">Adenine (A)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-teal-500 rounded"></div>
            <span className="text-gray-300">Thymine (T)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-blue-500 rounded"></div>
            <span className="text-gray-300">Guanine (G)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-yellow-500 rounded"></div>
            <span className="text-gray-300">Cytosine (C)</span>
          </div>
        </div>
        <div className="mt-4 pt-3 border-t border-white/20 text-xs text-gray-400">
          <div>A pairs with T</div>
          <div>G pairs with C</div>
        </div>
      </div>

      {/* Instructions */}
      <div className="absolute bottom-5 left-5 bg-black/80 backdrop-blur-md rounded-xl p-4 border border-white/20 max-w-sm">
        <h3 className="text-white font-bold mb-2">DNA Structure</h3>
        <ul className="text-gray-300 text-sm space-y-1">
          <li>• Double helix with complementary base pairs</li>
          <li>• Sugar-phosphate backbone (gray cylinders)</li>
          <li>• Hydrogen bonds between bases (white lines)</li>
          <li>• Antiparallel strands with major/minor grooves</li>
        </ul>
      </div>

      {/* Statistics */}
      <div className="absolute bottom-5 right-5 bg-black/80 backdrop-blur-md rounded-xl p-4 border border-white/20">
        <h3 className="text-white font-bold mb-2">Statistics</h3>
        <div className="text-gray-300 text-sm space-y-1">
          <div>Base Pairs: <span className="text-white font-semibold">{basePairsRef.current.length}</span></div>
          <div>AT Pairs: <span className="text-red-400 font-semibold">{basePairsRef.current.filter(p => p.type === 'AT').length}</span></div>
          <div>GC Pairs: <span className="text-blue-400 font-semibold">{basePairsRef.current.filter(p => p.type === 'GC').length}</span></div>
          <div>Helix Turns: <span className="text-white font-semibold">2.0</span></div>
        </div>
      </div>
    </div>
  );
}
