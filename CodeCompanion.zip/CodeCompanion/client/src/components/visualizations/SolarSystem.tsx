import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";

interface Planet {
  mesh: THREE.Mesh;
  orbit: THREE.Line;
  distance: number;
  speed: number;
  size: number;
  angle: number;
  name: string;
  color: number;
  moons?: Planet[];
}

export default function SolarSystem() {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const animationIdRef = useRef<number>(0);
  const clockRef = useRef<THREE.Clock>(new THREE.Clock());
  
  const [timeScale, setTimeScale] = useState(1);
  const [showOrbits, setShowOrbits] = useState(true);
  const [showLabels, setShowLabels] = useState(false);
  const [selectedPlanet, setSelectedPlanet] = useState<string | null>(null);
  
  const planetsRef = useRef<Planet[]>([]);
  const sunRef = useRef<THREE.Mesh | null>(null);
  
  const navigate = useNavigate();

  const planetData = [
    { 
      name: "Mercúrio", 
      distance: 8, 
      speed: 0.04, 
      size: 0.2, 
      color: 0x8c7853,
      emissive: 0x2a1f15,
      roughness: 0.9,
      metalness: 0.1
    },
    { 
      name: "Vênus", 
      distance: 12, 
      speed: 0.03, 
      size: 0.3, 
      color: 0xffc649,
      emissive: 0x332a11,
      roughness: 0.4,
      metalness: 0.0,
      hasAtmosphere: true,
      atmosphereColor: 0xffaa22
    },
    { 
      name: "Terra", 
      distance: 16, 
      speed: 0.02, 
      size: 0.32, 
      color: 0x6b93d6,
      emissive: 0x0a1a2e,
      roughness: 0.7,
      metalness: 0.2,
      hasAtmosphere: true,
      atmosphereColor: 0x87ceeb,
      hasClouds: true
    },
    { 
      name: "Marte", 
      distance: 20, 
      speed: 0.018, 
      size: 0.25, 
      color: 0xc1440e,
      emissive: 0x2e0f03,
      roughness: 0.9,
      metalness: 0.0,
      hasAtmosphere: true,
      atmosphereColor: 0xcd5c5c
    },
    { 
      name: "Júpiter", 
      distance: 28, 
      speed: 0.013, 
      size: 1.2, 
      color: 0xd8ca9d,
      emissive: 0x332e26,
      roughness: 0.5,
      metalness: 0.0,
      hasAtmosphere: true,
      atmosphereColor: 0xf4a460,
      hasStripes: true
    },
    { 
      name: "Saturno", 
      distance: 36, 
      speed: 0.009, 
      size: 1.0, 
      color: 0xfad5a5,
      emissive: 0x332b21,
      roughness: 0.6,
      metalness: 0.0,
      hasRings: true,
      hasAtmosphere: true,
      atmosphereColor: 0xffe4b5
    },
    { 
      name: "Urano", 
      distance: 44, 
      speed: 0.006, 
      size: 0.8, 
      color: 0x4fd0e3,
      emissive: 0x0f2a2e,
      roughness: 0.3,
      metalness: 0.1,
      hasAtmosphere: true,
      atmosphereColor: 0x40e0d0,
      hasRings: true
    },
    { 
      name: "Netuno", 
      distance: 52, 
      speed: 0.005, 
      size: 0.78, 
      color: 0x4b70dd,
      emissive: 0x0f1633,
      roughness: 0.4,
      metalness: 0.1,
      hasAtmosphere: true,
      atmosphereColor: 0x6495ed
    },
  ];

  useEffect(() => {
    if (!containerRef.current) return;

    // Initialize Three.js scene
    const scene = new THREE.Scene();
    const starGeometry = new THREE.BufferGeometry();
    const starMaterial = new THREE.PointsMaterial({ color: 0xffffff, size: 0.5 });
    
    // Create starfield
    const starVertices = [];
    for (let i = 0; i < 10000; i++) {
      starVertices.push(
        (Math.random() - 0.5) * 2000,
        (Math.random() - 0.5) * 2000,
        (Math.random() - 0.5) * 2000
      );
    }
    starGeometry.setAttribute('position', new THREE.Float32BufferAttribute(starVertices, 3));
    const stars = new THREE.Points(starGeometry, starMaterial);
    scene.add(stars);
    
    sceneRef.current = scene;

    // Camera setup
    const camera = new THREE.PerspectiveCamera(
      60,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    camera.position.set(30, 30, 30);
    cameraRef.current = camera;

    // Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.minDistance = 3;
    controls.maxDistance = 200;
    controlsRef.current = controls;

    // Create solar system
    createSolarSystem();

    // Animation loop
    const animate = () => {
      animationIdRef.current = requestAnimationFrame(animate);
      
      const deltaTime = clockRef.current.getDelta() * timeScale;
      
      // Update planet positions with enhanced animations
      const currentTime = Date.now() * 0.001;
      
      planetsRef.current.forEach((planet, planetIndex) => {
        planet.angle += planet.speed * deltaTime;
        planet.mesh.position.x = Math.cos(planet.angle) * planet.distance;
        planet.mesh.position.z = Math.sin(planet.angle) * planet.distance;
        
        // Different rotation speeds for different planets
        const rotationSpeed = planet.name === "Júpiter" ? 0.03 : 
                            planet.name === "Saturno" ? 0.025 : 
                            planet.name === "Terra" ? 0.02 : 0.015;
        planet.mesh.rotation.y += rotationSpeed * timeScale;
        
        // Animate clouds for Earth
        if (planet.name === "Terra" && planet.mesh.children.length > 0) {
          planet.mesh.children.forEach(child => {
            if (child.material && (child.material as any).color?.getHex() === 0xffffff) {
              child.rotation.y += 0.008 * timeScale; // Slower cloud rotation
            }
          });
        }

        // Animate atmosphere glow with pulsing effect
        if (planet.mesh.children.length > 0) {
          planet.mesh.children.forEach(child => {
            if (child.material && (child.material as any).transparent) {
              const material = child.material as THREE.MeshBasicMaterial;
              if (material.opacity < 0.5) {
                material.opacity = 0.15 + Math.sin(currentTime * 2 + planetIndex) * 0.08;
              }
            }
          });
        }

        // Animate Saturn's rings rotation
        if (planet.name === "Saturno" && planet.mesh.children.length > 0) {
          planet.mesh.children.forEach(child => {
            if (child.geometry && child.geometry.type === "RingGeometry") {
              child.rotation.z += 0.004 * timeScale;
            }
          });
        }

        // Animate Uranus tilted rings
        if (planet.name === "Urano" && planet.mesh.children.length > 0) {
          planet.mesh.children.forEach(child => {
            if (child.geometry && child.geometry.type === "RingGeometry") {
              child.rotation.y += 0.002 * timeScale;
            }
          });
        }
        
        // Update moons with enhanced orbital mechanics
        if (planet.moons) {
          planet.moons.forEach((moon, moonIndex) => {
            moon.angle += moon.speed * deltaTime * 8; // Moons orbit faster
            const moonX = planet.mesh.position.x + Math.cos(moon.angle) * moon.distance;
            const moonZ = planet.mesh.position.z + Math.sin(moon.angle) * moon.distance;
            
            // Add slight vertical oscillation for more realistic orbits
            const moonY = Math.sin(moon.angle * 2) * 0.1;
            moon.mesh.position.set(moonX, moonY, moonZ);
            
            // Rotate moons
            moon.mesh.rotation.y += (0.02 + moonIndex * 0.005) * timeScale;
          });
        }
      });
      
      // Enhanced sun animation with dynamic effects
      if (sunRef.current) {
        sunRef.current.rotation.y += 0.008 * timeScale;
        
        // Animate sun corona with counter-rotation
        if (sunRef.current.children.length > 0) {
          const corona = sunRef.current.children[0];
          if (corona.material) {
            const coronaMaterial = corona.material as THREE.MeshBasicMaterial;
            coronaMaterial.opacity = 0.12 + Math.sin(currentTime * 4) * 0.08;
          }
          corona.rotation.y -= 0.006 * timeScale;
        }

        // Animate sun material with pulsing color
        const sunMaterial = sunRef.current.material as THREE.MeshBasicMaterial;
        const intensity = 0.8 + Math.sin(currentTime * 3) * 0.2;
        sunMaterial.color.setRGB(intensity, intensity * 0.8, 0);
      }
      
      if (controlsRef.current) {
        controlsRef.current.update();
      }
      
      if (rendererRef.current && sceneRef.current) {
        rendererRef.current.render(sceneRef.current, camera);
      }
    };
    animate();

    // Handle window resize
    const handleResize = () => {
      if (cameraRef.current && rendererRef.current) {
        cameraRef.current.aspect = window.innerWidth / window.innerHeight;
        cameraRef.current.updateProjectionMatrix();
        rendererRef.current.setSize(window.innerWidth, window.innerHeight);
      }
    };
    
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      
      if (animationIdRef.current) {
        cancelAnimationFrame(animationIdRef.current);
      }
      
      if (containerRef.current && rendererRef.current) {
        containerRef.current.removeChild(rendererRef.current.domElement);
      }
      
      if (sceneRef.current) {
        sceneRef.current.clear();
      }
      if (rendererRef.current) {
        rendererRef.current.dispose();
      }
    };
  }, []);

  const createSolarSystem = () => {
    if (!sceneRef.current) return;

    // Clear existing planets
    planetsRef.current.forEach(planet => {
      sceneRef.current?.remove(planet.mesh);
      sceneRef.current?.remove(planet.orbit);
      if (planet.moons) {
        planet.moons.forEach(moon => {
          sceneRef.current?.remove(moon.mesh);
        });
      }
    });

    // Clear existing sun
    if (sunRef.current) {
      sceneRef.current.remove(sunRef.current);
    }

    // Create enhanced sun with glow effect
    const sunGeometry = new THREE.SphereGeometry(2.2, 64, 64);
    const sunMaterial = new THREE.MeshBasicMaterial({ 
      color: 0xffff00
    });
    const sun = new THREE.Mesh(sunGeometry, sunMaterial);
    
    // Add sun corona/glow
    const coronaGeometry = new THREE.SphereGeometry(2.8, 32, 32);
    const coronaMaterial = new THREE.MeshBasicMaterial({
      color: 0xffaa00,
      transparent: true,
      opacity: 0.15,
      side: THREE.BackSide
    });
    const corona = new THREE.Mesh(coronaGeometry, coronaMaterial);
    sun.add(corona);
    
    sceneRef.current.add(sun);
    sunRef.current = sun;

    // Enhanced lighting system
    const sunLight = new THREE.PointLight(0xffffff, 3, 200);
    sunLight.position.set(0, 0, 0);
    sceneRef.current.add(sunLight);

    const ambientLight = new THREE.AmbientLight(0x202040, 0.4);
    sceneRef.current.add(ambientLight);

    // Create starfield background
    const starGeometry = new THREE.BufferGeometry();
    const starCount = 2000;
    const starPositions = new Float32Array(starCount * 3);
    const starColors = new Float32Array(starCount * 3);
    
    for (let i = 0; i < starCount * 3; i += 3) {
      // Random positions in a large sphere
      const radius = 300 + Math.random() * 200;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      
      starPositions[i] = radius * Math.sin(phi) * Math.cos(theta);
      starPositions[i + 1] = radius * Math.sin(phi) * Math.sin(theta);
      starPositions[i + 2] = radius * Math.cos(phi);
      
      // Random star colors (white, blue, yellow, red)
      const colorChoice = Math.random();
      if (colorChoice < 0.7) {
        // White stars
        starColors[i] = 1;
        starColors[i + 1] = 1;
        starColors[i + 2] = 1;
      } else if (colorChoice < 0.85) {
        // Blue stars
        starColors[i] = 0.6;
        starColors[i + 1] = 0.8;
        starColors[i + 2] = 1;
      } else if (colorChoice < 0.95) {
        // Yellow stars
        starColors[i] = 1;
        starColors[i + 1] = 1;
        starColors[i + 2] = 0.6;
      } else {
        // Red stars
        starColors[i] = 1;
        starColors[i + 1] = 0.6;
        starColors[i + 2] = 0.6;
      }
    }
    
    starGeometry.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
    starGeometry.setAttribute('color', new THREE.BufferAttribute(starColors, 3));
    
    const starMaterial = new THREE.PointsMaterial({
      size: 2,
      vertexColors: true,
      transparent: true,
      opacity: 0.8
    });
    
    const stars = new THREE.Points(starGeometry, starMaterial);
    sceneRef.current.add(stars);

    // Create planets with enhanced visuals
    planetsRef.current = [];
    
    planetData.forEach((data, index) => {
      // Create planet with enhanced materials
      const planetGeometry = new THREE.SphereGeometry(data.size, 64, 64);
      const planetMaterial = new THREE.MeshStandardMaterial({ 
        color: data.color,
        emissive: data.emissive || 0x000000,
        emissiveIntensity: 0.1,
        roughness: data.roughness || 0.7,
        metalness: data.metalness || 0.1
      });
      const planetMesh = new THREE.Mesh(planetGeometry, planetMaterial);
      planetMesh.position.set(data.distance, 0, 0);
      
      // Add atmosphere for applicable planets
      if (data.hasAtmosphere) {
        const atmosphereGeometry = new THREE.SphereGeometry(data.size * 1.05, 32, 32);
        const atmosphereMaterial = new THREE.MeshBasicMaterial({
          color: data.atmosphereColor || data.color,
          transparent: true,
          opacity: 0.2,
          side: THREE.BackSide
        });
        const atmosphere = new THREE.Mesh(atmosphereGeometry, atmosphereMaterial);
        planetMesh.add(atmosphere);
      }

      // Add clouds for Earth
      if (data.hasClouds) {
        const cloudGeometry = new THREE.SphereGeometry(data.size * 1.02, 32, 32);
        const cloudMaterial = new THREE.MeshLambertMaterial({
          color: 0xffffff,
          transparent: true,
          opacity: 0.4
        });
        const clouds = new THREE.Mesh(cloudGeometry, cloudMaterial);
        planetMesh.add(clouds);
      }

      // Enhanced orbit lines
      const orbitGeometry = new THREE.RingGeometry(
        data.distance - 0.05, 
        data.distance + 0.05, 
        128
      );
      const orbitMaterial = new THREE.MeshBasicMaterial({ 
        color: 0x666666,
        transparent: true,
        opacity: showOrbits ? 0.4 : 0,
        side: THREE.DoubleSide
      });
      const orbitMesh = new THREE.Mesh(orbitGeometry, orbitMaterial);
      orbitMesh.rotation.x = -Math.PI / 2;
      
      sceneRef.current.add(planetMesh);
      sceneRef.current.add(orbitMesh);

      const planet: Planet = {
        mesh: planetMesh,
        orbit: orbitMesh as any,
        distance: data.distance,
        speed: data.speed,
        size: data.size,
        angle: Math.random() * Math.PI * 2,
        name: data.name,
        color: data.color
      };

      // Enhanced Earth's moon
      if (data.name === "Terra") {
        const moonGeometry = new THREE.SphereGeometry(0.08, 32, 32);
        const moonMaterial = new THREE.MeshStandardMaterial({ 
          color: 0xcccccc,
          roughness: 0.9,
          emissive: 0x111111,
          emissiveIntensity: 0.05
        });
        const moonMesh = new THREE.Mesh(moonGeometry, moonMaterial);
        sceneRef.current.add(moonMesh);

        planet.moons = [{
          mesh: moonMesh,
          orbit: orbitMesh as any,
          distance: 1.5,
          speed: 0.1,
          size: 0.08,
          angle: 0,
          name: "Lua",
          color: 0xcccccc
        }];
      }

      // Enhanced Saturn's rings
      if (data.hasRings && data.name === "Saturno") {
        // Main ring system
        const ringGeometry1 = new THREE.RingGeometry(data.size + 0.3, data.size + 0.7, 64);
        const ringMaterial1 = new THREE.MeshBasicMaterial({ 
          color: 0xdddddd,
          transparent: true,
          opacity: 0.8,
          side: THREE.DoubleSide
        });
        const ring1 = new THREE.Mesh(ringGeometry1, ringMaterial1);
        ring1.rotation.x = -Math.PI / 2;
        
        // Secondary ring
        const ringGeometry2 = new THREE.RingGeometry(data.size + 0.8, data.size + 1.0, 64);
        const ringMaterial2 = new THREE.MeshBasicMaterial({ 
          color: 0xbbbbbb,
          transparent: true,
          opacity: 0.6,
          side: THREE.DoubleSide
        });
        const ring2 = new THREE.Mesh(ringGeometry2, ringMaterial2);
        ring2.rotation.x = -Math.PI / 2;
        
        planetMesh.add(ring1);
        planetMesh.add(ring2);
      }

      // Uranus rings (thinner)
      if (data.hasRings && data.name === "Urano") {
        const ringGeometry = new THREE.RingGeometry(data.size + 0.2, data.size + 0.35, 64);
        const ringMaterial = new THREE.MeshBasicMaterial({ 
          color: 0x888888,
          transparent: true,
          opacity: 0.5,
          side: THREE.DoubleSide
        });
        const ring = new THREE.Mesh(ringGeometry, ringMaterial);
        ring.rotation.x = -Math.PI / 2;
        ring.rotation.z = Math.PI / 4; // Tilted rings for Uranus
        planetMesh.add(ring);
      }

      // Add Jupiter's moons (Io, Europa, Ganymede, Callisto)
      if (data.name === "Júpiter") {
        const jupiterMoons = [
          { name: "Io", distance: 2.2, size: 0.05, color: 0xffff88, speed: 0.15 },
          { name: "Europa", distance: 2.8, size: 0.04, color: 0xaaaaff, speed: 0.12 },
          { name: "Ganímedes", distance: 3.5, size: 0.06, color: 0x888888, speed: 0.09 },
          { name: "Calisto", distance: 4.2, size: 0.055, color: 0x666666, speed: 0.07 }
        ];

        planet.moons = jupiterMoons.map(moonData => {
          const moonGeometry = new THREE.SphereGeometry(moonData.size, 16, 16);
          const moonMaterial = new THREE.MeshStandardMaterial({ 
            color: moonData.color,
            roughness: 0.8
          });
          const moonMesh = new THREE.Mesh(moonGeometry, moonMaterial);
          sceneRef.current?.add(moonMesh);

          return {
            mesh: moonMesh,
            orbit: orbitMesh as any,
            distance: moonData.distance,
            speed: moonData.speed,
            size: moonData.size,
            angle: Math.random() * Math.PI * 2,
            name: moonData.name,
            color: moonData.color
          };
        });
      }

      planetsRef.current.push(planet);
    });

    // Add asteroid belt between Mars and Jupiter
    const asteroidCount = 200;
    for (let i = 0; i < asteroidCount; i++) {
      const asteroidGeometry = new THREE.SphereGeometry(
        0.01 + Math.random() * 0.03, 
        8, 8
      );
      const asteroidMaterial = new THREE.MeshStandardMaterial({ 
        color: 0x888888,
        roughness: 0.9
      });
      const asteroid = new THREE.Mesh(asteroidGeometry, asteroidMaterial);
      
      const angle = Math.random() * Math.PI * 2;
      const distance = 24 + Math.random() * 2; // Between Mars and Jupiter
      const height = (Math.random() - 0.5) * 0.5;
      
      asteroid.position.set(
        Math.cos(angle) * distance,
        height,
        Math.sin(angle) * distance
      );
      
      sceneRef.current.add(asteroid);
    }
  };

  const focusOnPlanet = (planetName: string) => {
    const planet = planetsRef.current.find(p => p.name === planetName);
    if (planet && cameraRef.current && controlsRef.current) {
      const targetPosition = new THREE.Vector3();
      planet.mesh.getWorldPosition(targetPosition);
      
      // Move camera to look at the planet
      const distance = planet.size * 8 + 5;
      cameraRef.current.position.set(
        targetPosition.x + distance,
        targetPosition.y + distance/2,
        targetPosition.z + distance
      );
      
      controlsRef.current.target.copy(targetPosition);
      setSelectedPlanet(planetName);
    }
  };

  const resetCamera = () => {
    if (cameraRef.current && controlsRef.current) {
      cameraRef.current.position.set(30, 30, 30);
      controlsRef.current.target.set(0, 0, 0);
      setSelectedPlanet(null);
    }
  };

  const toggleOrbits = () => {
    const newShowOrbits = !showOrbits;
    setShowOrbits(newShowOrbits);
    
    planetsRef.current.forEach(planet => {
      planet.orbit.material.opacity = newShowOrbits ? 0.3 : 0;
    });
  };

  useEffect(() => {
    if (sceneRef.current) {
      createSolarSystem();
    }
  }, []);

  useEffect(() => {
    if (sceneRef.current) {
      createSolarSystem();
    }
  }, [showOrbits]);

  return (
    <div className="w-full h-screen relative overflow-hidden">
      <div ref={containerRef} className="w-full h-full" />
      
      {/* Control Panel */}
      <div className="absolute top-5 left-5 bg-black/80 backdrop-blur-md rounded-xl p-4 border border-white/20 max-w-xs">
        <button
          onClick={() => navigate("/")}
          className="mb-4 w-full bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-500 hover:to-gray-600 text-white font-bold py-2 px-4 rounded-lg transition-all duration-300"
        >
          ← Voltar à Galeria
        </button>
        
        <div className="mb-4">
          <label className="block text-white text-sm font-medium mb-2">
            Escala de Tempo: {timeScale.toFixed(1)}x
          </label>
          <input
            type="range"
            min="0"
            max="5"
            step="0.1"
            value={timeScale}
            onChange={(e) => setTimeScale(Number(e.target.value))}
            className="w-full"
          />
        </div>
        
        <button
          onClick={resetCamera}
          className="mb-3 w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-400 hover:to-purple-500 text-white font-bold py-2 px-4 rounded-lg transition-all duration-300"
        >
          🌌 Visão do Sistema Solar
        </button>
        
        <div className="flex items-center justify-between text-white text-sm py-2 border-t border-white/20 mb-2">
          <label htmlFor="orbits-toggle">Mostrar Órbitas</label>
          <input
            id="orbits-toggle"
            type="checkbox"
            checked={showOrbits}
            onChange={toggleOrbits}
            className="w-8 h-4 bg-gray-600 rounded-full relative cursor-pointer appearance-none checked:bg-blue-500 transition-colors"
          />
        </div>
        
        <div className="flex items-center justify-between text-white text-sm py-2 border-t border-white/20">
          <label htmlFor="labels-toggle">Mostrar Rótulos</label>
          <input
            id="labels-toggle"
            type="checkbox"
            checked={showLabels}
            onChange={(e) => setShowLabels(e.target.checked)}
            className="w-8 h-4 bg-gray-600 rounded-full relative cursor-pointer appearance-none checked:bg-blue-500 transition-colors"
          />
        </div>
      </div>

      {/* Planet Selector */}
      <div className="absolute top-5 right-5 bg-black/80 backdrop-blur-md rounded-xl p-4 border border-white/20 max-w-xs">
        <h3 className="text-white font-bold mb-3">Selecionar Planeta</h3>
        <div className="grid grid-cols-2 gap-2">
          {planetData.map((planet) => (
            <button
              key={planet.name}
              onClick={() => focusOnPlanet(planet.name)}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
                selectedPlanet === planet.name
                  ? "bg-blue-500 text-white"
                  : "bg-gray-700 text-gray-300 hover:bg-gray-600"
              }`}
            >
              {planet.name}
            </button>
          ))}
        </div>
      </div>

      {/* Planet Info */}
      {selectedPlanet && (
        <div className="absolute bottom-5 right-5 bg-black/80 backdrop-blur-md rounded-xl p-4 border border-white/20 max-w-sm">
          <h3 className="text-2xl font-bold text-white mb-2">{selectedPlanet}</h3>
          <div className="text-gray-300 text-sm space-y-1">
            {selectedPlanet === "Mercury" && (
              <>
                <div>Closest planet to the Sun</div>
                <div>Temperature: -170°C to 430°C</div>
                <div>Day length: 59 Earth days</div>
                <div>No moons, no atmosphere</div>
              </>
            )}
            {selectedPlanet === "Venus" && (
              <>
                <div>Hottest planet in solar system</div>
                <div>Temperature: 462°C (surface)</div>
                <div>Thick, toxic atmosphere</div>
                <div>Rotates backwards</div>
              </>
            )}
            {selectedPlanet === "Earth" && (
              <>
                <div>Our home planet</div>
                <div>71% water coverage</div>
                <div>Only known planet with life</div>
                <div>One natural satellite: The Moon</div>
              </>
            )}
            {selectedPlanet === "Mars" && (
              <>
                <div>The Red Planet</div>
                <div>Iron oxide gives red color</div>
                <div>Two small moons: Phobos & Deimos</div>
                <div>Potential for past/present life</div>
              </>
            )}
            {selectedPlanet === "Jupiter" && (
              <>
                <div>Largest planet in solar system</div>
                <div>Gas giant with Great Red Spot</div>
                <div>Over 80 known moons</div>
                <div>Could fit all other planets inside</div>
              </>
            )}
            {selectedPlanet === "Saturn" && (
              <>
                <div>Famous for its ring system</div>
                <div>Less dense than water</div>
                <div>Over 80 known moons</div>
                <div>Titan is larger than Mercury</div>
              </>
            )}
            {selectedPlanet === "Uranus" && (
              <>
                <div>Ice giant tilted on its side</div>
                <div>Coldest planetary atmosphere</div>
                <div>27 known moons</div>
                <div>Faint ring system</div>
              </>
            )}
            {selectedPlanet === "Neptune" && (
              <>
                <div>Windiest planet (2,100 km/h)</div>
                <div>Furthest known planet from Sun</div>
                <div>14 known moons</div>
                <div>Deep blue color from methane</div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Instructions */}
      <div className="absolute bottom-5 left-5 bg-black/80 backdrop-blur-md rounded-xl p-4 border border-white/20 max-w-sm">
        <h3 className="text-white font-bold mb-2">Controls</h3>
        <ul className="text-gray-300 text-sm space-y-1">
          <li>• Drag to rotate view</li>
          <li>• Scroll to zoom in/out</li>
          <li>• Click planets to focus</li>
          <li>• Adjust time scale for speed</li>
          <li>• Toggle orbits for cleaner view</li>
        </ul>
      </div>
    </div>
  );
}
