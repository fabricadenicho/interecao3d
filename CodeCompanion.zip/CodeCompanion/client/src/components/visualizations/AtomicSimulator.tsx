import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";

interface ElectronOrbit {
  mesh: THREE.Mesh;
  orbit: THREE.Line;
  radius: number;
  speed: number;
  angle: number;
  inclination: number;
  path: THREE.EllipseCurve;
}

export default function AtomicSimulator() {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const animationIdRef = useRef<number>(0);
  const clockRef = useRef<THREE.Clock>(new THREE.Clock());
  
  const [atomicNumber, setAtomicNumber] = useState(6); // Carbon by default
  const [showOrbits, setShowOrbits] = useState(true);
  const [animationSpeed, setAnimationSpeed] = useState(1);
  
  const electronsRef = useRef<ElectronOrbit[]>([]);
  const nucleusGroupRef = useRef<THREE.Group | null>(null);
  
  const navigate = useNavigate();

  const atomicData: { [key: number]: { name: string; protons: number; neutrons: number; electrons: number } } = {
    1: { name: "Hidrogênio", protons: 1, neutrons: 0, electrons: 1 },
    2: { name: "Hélio", protons: 2, neutrons: 2, electrons: 2 },
    3: { name: "Lítio", protons: 3, neutrons: 4, electrons: 3 },
    4: { name: "Berílio", protons: 4, neutrons: 5, electrons: 4 },
    5: { name: "Boro", protons: 5, neutrons: 6, electrons: 5 },
    6: { name: "Carbono", protons: 6, neutrons: 6, electrons: 6 },
    7: { name: "Nitrogênio", protons: 7, neutrons: 7, electrons: 7 },
    8: { name: "Oxigênio", protons: 8, neutrons: 8, electrons: 8 },
    9: { name: "Flúor", protons: 9, neutrons: 10, electrons: 9 },
    10: { name: "Neônio", protons: 10, neutrons: 10, electrons: 10 },
  };

  useEffect(() => {
    if (!containerRef.current) return;

    // Initialize Three.js scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0a0f);
    sceneRef.current = scene;

    // Camera setup
    const camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    camera.position.set(12, 8, 12);
    cameraRef.current = camera;

    // Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.3);
    scene.add(ambientLight);
    
    const pointLight = new THREE.PointLight(0xffffff, 1, 100);
    pointLight.position.set(10, 10, 10);
    scene.add(pointLight);

    // Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.minDistance = 3;
    controls.maxDistance = 50;
    controlsRef.current = controls;

    // Build initial atom
    buildAtom();

    // Animation loop
    const animate = () => {
      animationIdRef.current = requestAnimationFrame(animate);
      
      const deltaTime = clockRef.current.getDelta() * animationSpeed;
      
      // Update electron positions
      electronsRef.current.forEach(electron => {
        electron.angle += electron.speed * deltaTime;
        
        const x = Math.cos(electron.angle) * electron.radius;
        const z = Math.sin(electron.angle) * electron.radius * 0.7; // Elliptical
        const y = Math.sin(electron.angle + electron.inclination) * electron.radius * 0.3;
        
        electron.mesh.position.set(x, y, z);
      });
      
      // Rotate nucleus slightly
      if (nucleusGroupRef.current) {
        nucleusGroupRef.current.rotation.y += 0.005 * animationSpeed;
        nucleusGroupRef.current.rotation.x += 0.003 * animationSpeed;
      }
      
      if (controlsRef.current) {
        controlsRef.current.update();
      }
      
      if (rendererRef.current && sceneRef.current) {
        rendererRef.current.render(sceneRef.current, camera);
      }
    };
    animate();

    // Handle window resize
    const handleResize = () => {
      if (cameraRef.current && rendererRef.current) {
        cameraRef.current.aspect = window.innerWidth / window.innerHeight;
        cameraRef.current.updateProjectionMatrix();
        rendererRef.current.setSize(window.innerWidth, window.innerHeight);
      }
    };
    
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      
      if (animationIdRef.current) {
        cancelAnimationFrame(animationIdRef.current);
      }
      
      if (containerRef.current && rendererRef.current) {
        containerRef.current.removeChild(rendererRef.current.domElement);
      }
      
      if (sceneRef.current) {
        sceneRef.current.clear();
      }
      if (rendererRef.current) {
        rendererRef.current.dispose();
      }
    };
  }, []);

  const buildAtom = () => {
    if (!sceneRef.current) return;

    // Clear existing atom
    if (nucleusGroupRef.current) {
      sceneRef.current.remove(nucleusGroupRef.current);
    }
    
    electronsRef.current.forEach(electron => {
      sceneRef.current?.remove(electron.mesh);
      sceneRef.current?.remove(electron.orbit);
    });
    electronsRef.current = [];

    const atom = atomicData[atomicNumber];
    if (!atom) return;

    // Create nucleus
    const nucleusGroup = new THREE.Group();
    
    // Create protons and neutrons
    const particleRadius = 0.3;
    const totalParticles = atom.protons + atom.neutrons;
    
    for (let i = 0; i < totalParticles; i++) {
      const isProton = i < atom.protons;
      const geometry = new THREE.SphereGeometry(particleRadius, 16, 16);
      const material = new THREE.MeshStandardMaterial({
        color: isProton ? 0xff4444 : 0x888888,
        roughness: 0.5,
        metalness: 0.2
      });
      
      const particle = new THREE.Mesh(geometry, material);
      
      // Arrange particles in a rough sphere
      const phi = Math.acos(-1 + (2 * i) / totalParticles);
      const theta = Math.sqrt(totalParticles * Math.PI) * phi;
      
      particle.position.set(
        Math.cos(theta) * Math.sin(phi) * 0.8,
        Math.sin(theta) * Math.sin(phi) * 0.8,
        Math.cos(phi) * 0.8
      );
      
      nucleusGroup.add(particle);
    }
    
    sceneRef.current.add(nucleusGroup);
    nucleusGroupRef.current = nucleusGroup;

    // Create electron shells
    const shellRadii = [3, 5, 7, 9]; // Distance from nucleus
    const maxElectronsPerShell = [2, 8, 18, 32];
    
    let electronsPlaced = 0;
    let shellIndex = 0;
    
    while (electronsPlaced < atom.electrons && shellIndex < shellRadii.length) {
      const electronsInThisShell = Math.min(
        atom.electrons - electronsPlaced,
        maxElectronsPerShell[shellIndex]
      );
      
      const radius = shellRadii[shellIndex];
      
      for (let i = 0; i < electronsInThisShell; i++) {
        // Create electron
        const electronGeometry = new THREE.SphereGeometry(0.1, 12, 12);
        const electronMaterial = new THREE.MeshBasicMaterial({ 
          color: 0x00aaff,
          transparent: true,
          opacity: 0.8
        });
        const electron = new THREE.Mesh(electronGeometry, electronMaterial);
        
        // Create orbital path
        const orbitGeometry = new THREE.RingGeometry(radius - 0.05, radius + 0.05, 64);
        const orbitMaterial = new THREE.LineBasicMaterial({ 
          color: 0x444488,
          transparent: true,
          opacity: showOrbits ? 0.3 : 0
        });
        
        const orbitCurve = new THREE.EllipseCurve(0, 0, radius, radius * 0.7, 0, 2 * Math.PI, false, 0);
        const orbitPoints = orbitCurve.getPoints(100);
        const orbitLineGeometry = new THREE.BufferGeometry().setFromPoints(orbitPoints);
        const orbit = new THREE.Line(orbitLineGeometry, orbitMaterial);
        
        // Random inclination for 3D effect
        const inclination = (Math.random() - 0.5) * Math.PI;
        orbit.rotation.x = inclination;
        orbit.rotation.z = (i / electronsInThisShell) * Math.PI * 2;
        
        sceneRef.current?.add(electron);
        sceneRef.current?.add(orbit);
        
        electronsRef.current.push({
          mesh: electron,
          orbit,
          radius,
          speed: 1 / radius + Math.random() * 0.5, // Faster orbits for inner shells
          angle: (i / electronsInThisShell) * Math.PI * 2,
          inclination,
          path: orbitCurve
        });
      }
      
      electronsPlaced += electronsInThisShell;
      shellIndex++;
    }
  };

  const changeAtom = (newAtomicNumber: number) => {
    setAtomicNumber(newAtomicNumber);
    buildAtom();
  };

  const toggleOrbits = () => {
    const newShowOrbits = !showOrbits;
    setShowOrbits(newShowOrbits);
    
    electronsRef.current.forEach(electron => {
      electron.orbit.material.opacity = newShowOrbits ? 0.3 : 0;
    });
  };

  useEffect(() => {
    buildAtom();
  }, [atomicNumber]);

  const currentAtom = atomicData[atomicNumber];

  return (
    <div className="w-full h-screen relative overflow-hidden">
      <div ref={containerRef} className="w-full h-full" />
      
      {/* Control Panel */}
      <div className="absolute top-5 left-5 bg-black/80 backdrop-blur-md rounded-xl p-4 border border-white/20 max-w-xs">
        <button
          onClick={() => navigate("/")}
          className="mb-4 w-full bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-500 hover:to-gray-600 text-white font-bold py-2 px-4 rounded-lg transition-all duration-300"
        >
          ← Voltar à Galeria
        </button>
        
        <div className="mb-4">
          <label className="block text-white text-sm font-medium mb-2">
            Selecionar Elemento
          </label>
          <select
            value={atomicNumber}
            onChange={(e) => changeAtom(Number(e.target.value))}
            className="w-full bg-gray-700 text-white rounded-lg px-3 py-2 border border-gray-600 focus:border-blue-500 focus:outline-none"
          >
            {Object.entries(atomicData).map(([num, data]) => (
              <option key={num} value={num}>
                {data.name} ({num})
              </option>
            ))}
          </select>
        </div>
        
        <div className="mb-4">
          <label className="block text-white text-sm font-medium mb-2">
            Velocidade da Animação: {animationSpeed.toFixed(1)}x
          </label>
          <input
            type="range"
            min="0"
            max="3"
            step="0.1"
            value={animationSpeed}
            onChange={(e) => setAnimationSpeed(Number(e.target.value))}
            className="w-full"
          />
        </div>
        
        <div className="flex items-center justify-between text-white text-sm py-2 border-t border-white/20">
          <label htmlFor="orbits-toggle">Mostrar Caminhos Orbitais</label>
          <input
            id="orbits-toggle"
            type="checkbox"
            checked={showOrbits}
            onChange={toggleOrbits}
            className="w-8 h-4 bg-gray-600 rounded-full relative cursor-pointer appearance-none checked:bg-blue-500 transition-colors"
          />
        </div>
      </div>

      {/* Element Info */}
      {currentAtom && (
        <div className="absolute top-5 right-5 bg-black/80 backdrop-blur-md rounded-xl p-4 border border-white/20">
          <h2 className="text-2xl font-bold text-white mb-2">{currentAtom.name}</h2>
          <div className="text-gray-300 space-y-1">
            <div>Número Atômico: <span className="text-white font-semibold">{atomicNumber}</span></div>
            <div>Prótons: <span className="text-red-400 font-semibold">{currentAtom.protons}</span></div>
            <div>Nêutrons: <span className="text-gray-400 font-semibold">{currentAtom.neutrons}</span></div>
            <div>Elétrons: <span className="text-blue-400 font-semibold">{currentAtom.electrons}</span></div>
          </div>
        </div>
      )}

      {/* Legend */}
      <div className="absolute bottom-5 left-5 bg-black/80 backdrop-blur-md rounded-xl p-4 border border-white/20">
        <h3 className="text-white font-bold mb-2">Legenda</h3>
        <div className="space-y-2 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
            <span className="text-gray-300">Prótons</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-gray-500 rounded-full"></div>
            <span className="text-gray-300">Nêutrons</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
            <span className="text-gray-300">Elétrons</span>
          </div>
        </div>
      </div>

      {/* Instructions */}
      <div className="absolute bottom-5 right-5 bg-black/80 backdrop-blur-md rounded-xl p-4 border border-white/20 max-w-sm">
        <h3 className="text-white font-bold mb-2">Instruções</h3>
        <ul className="text-gray-300 text-sm space-y-1">
          <li>• Gire a visualização arrastando</li>
          <li>• Use a roda do mouse para zoom</li>
          <li>• Selecione diferentes elementos para explorar</li>
          <li>• Ajuste a velocidade da animação</li>
          <li>• Alterne visibilidade dos caminhos orbitais</li>
        </ul>
      </div>
    </div>
  );
}
