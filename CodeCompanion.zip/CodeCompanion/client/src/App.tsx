import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Suspense } from "react";
import Gallery from "./components/Gallery";
import NeuralNetworkPlayground from "./components/visualizations/NeuralNetworkPlayground";
import AtomicSimulator from "./components/visualizations/AtomicSimulator";
import DNAHelix from "./components/visualizations/DNAHelix";
import SolarSystem from "./components/visualizations/SolarSystem";
import ParticleField from "./components/visualizations/ParticleField";
import MathSurface from "./components/visualizations/MathSurface";
import LoadingSpinner from "./components/ui/LoadingSpinner";
import "@fontsource/inter";
import "./index.css";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: false,
    },
  },
});

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <div className="w-full h-full bg-[#111119] text-white">
          <Suspense fallback={<LoadingSpinner />}>
            <Routes>
              <Route path="/" element={<Gallery />} />
              <Route path="/neural-network" element={<NeuralNetworkPlayground />} />
              <Route path="/atomic-simulator" element={<AtomicSimulator />} />
              <Route path="/dna-helix" element={<DNAHelix />} />
              <Route path="/solar-system" element={<SolarSystem />} />
              <Route path="/particle-field" element={<ParticleField />} />
              <Route path="/math-surface" element={<MathSurface />} />
            </Routes>
          </Suspense>
        </div>
      </Router>
    </QueryClientProvider>
  );
}

export default App;
