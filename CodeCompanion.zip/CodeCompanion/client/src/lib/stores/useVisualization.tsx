import { create } from "zustand";

type VisualizationType = "neural-network" | "atomic-simulator" | "dna-helix" | "solar-system" | "particle-field" | null;

interface VisualizationState {
  currentVisualization: VisualizationType;
  isLoading: boolean;
  
  // Actions
  setVisualization: (type: VisualizationType) => void;
  setLoading: (loading: boolean) => void;
}

export const useVisualization = create<VisualizationState>((set) => ({
  currentVisualization: null,
  isLoading: false,
  
  setVisualization: (type) => set({ currentVisualization: type }),
  setLoading: (loading) => set({ isLoading: loading }),
}));
