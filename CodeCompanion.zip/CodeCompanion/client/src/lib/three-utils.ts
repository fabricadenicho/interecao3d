import * as THREE from "three";

// Utility functions for Three.js operations

export const createSphereGeometry = (radius: number, segments = 32) => {
  return new THREE.SphereGeometry(radius, segments, segments);
};

export const createStandardMaterial = (color: number, options?: Partial<THREE.MeshStandardMaterialParameters>) => {
  return new THREE.MeshStandardMaterial({
    color,
    roughness: 0.5,
    metalness: 0.1,
    ...options
  });
};

export const createBasicMaterial = (color: number, options?: Partial<THREE.MeshBasicMaterialParameters>) => {
  return new THREE.MeshBasicMaterial({
    color,
    ...options
  });
};

export const createLineGeometry = (points: THREE.Vector3[]) => {
  return new THREE.BufferGeometry().setFromPoints(points);
};

export const createLineMaterial = (color: number, options?: Partial<THREE.LineBasicMaterialParameters>) => {
  return new THREE.LineBasicMaterial({
    color,
    transparent: true,
    opacity: 0.6,
    ...options
  });
};

// Camera animation helpers
export const animateCamera = (
  camera: THREE.PerspectiveCamera,
  targetPosition: THREE.Vector3,
  targetLookAt: THREE.Vector3,
  duration = 1000
) => {
  const startPosition = camera.position.clone();
  const startTime = performance.now();

  const animate = () => {
    const elapsed = performance.now() - startTime;
    const progress = Math.min(elapsed / duration, 1);
    
    // Smooth easing function
    const easeProgress = 1 - Math.pow(1 - progress, 3);
    
    camera.position.lerpVectors(startPosition, targetPosition, easeProgress);
    camera.lookAt(targetLookAt);
    
    if (progress < 1) {
      requestAnimationFrame(animate);
    }
  };
  
  animate();
};

// Particle system helpers
export const createParticleSystem = (
  count: number,
  size: number,
  color: number,
  transparent = true
) => {
  const geometry = new THREE.BufferGeometry();
  const positions = new Float32Array(count * 3);
  
  for (let i = 0; i < count * 3; i++) {
    positions[i] = (Math.random() - 0.5) * 20;
  }
  
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  
  const material = new THREE.PointsMaterial({
    color,
    size,
    transparent,
    opacity: transparent ? 0.8 : 1.0,
    sizeAttenuation: true
  });
  
  return new THREE.Points(geometry, material);
};

// Lighting presets
export const createBasicLighting = (scene: THREE.Scene) => {
  const ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
  scene.add(ambientLight);
  
  const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
  directionalLight.position.set(10, 10, 5);
  scene.add(directionalLight);
  
  return { ambientLight, directionalLight };
};

export const createPointLighting = (scene: THREE.Scene, position: THREE.Vector3, color = 0xffffff, intensity = 1) => {
  const pointLight = new THREE.PointLight(color, intensity, 100);
  pointLight.position.copy(position);
  scene.add(pointLight);
  
  return pointLight;
};

// Math utilities
export const clamp = (value: number, min: number, max: number) => {
  return Math.max(min, Math.min(max, value));
};

export const lerp = (start: number, end: number, factor: number) => {
  return start + (end - start) * factor;
};

export const map = (value: number, inMin: number, inMax: number, outMin: number, outMax: number) => {
  return outMin + (outMax - outMin) * ((value - inMin) / (inMax - inMin));
};

// Color utilities
export const hexToRgb = (hex: number) => {
  const r = (hex >> 16) & 255;
  const g = (hex >> 8) & 255;
  const b = hex & 255;
  return { r: r / 255, g: g / 255, b: b / 255 };
};

export const rgbToHex = (r: number, g: number, b: number) => {
  return ((r * 255) << 16) + ((g * 255) << 8) + (b * 255);
};
